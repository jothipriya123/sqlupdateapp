import React, { useState } from 'react';
import Box from '@material-ui/core/Box';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import SendIcon from '@material-ui/icons/Send';

import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import axios from 'axios';

export default function Register() {
    const defaultValues = {
        firstname: "",
        lastname: "",
        emailID: "",
        employeeID:"",
        accesstype: "",
        oracleID: "",
        password: "",
        retypepassword: "",
    };

    const [responsemsg, setResponseMsg] = React.useState([]);
    const [errormsg, setErrorMsg] = React.useState([]);
    const [formValues, setFormValues] = useState(defaultValues);
    const [passwordError, setPasswordError] = useState("")
    const [confirmPasswordError, setConfirmPasswordError] = useState("")
    const [validatedpassword, setValidatedPassword] = useState(false)
    const [validatedConfirmPassword, setvalidatedconfirmpassword] = useState(false)
    const handleInputChange = (e) => {
        console.log("Entering", e.target.value);
        const { name, value } = e.target;
        console.log("Name", value)
        setFormValues({
            ...formValues,
            [name]: value,
        });
        if (name === "password") {
            validatePassword();
        }
        if (name === "retypepassword") {
            validateConfirmPassword();
        }
    };
    const validatePassword = () => {
        var regex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#-._\\\\/()$%^&*:;'}{|\"+,<=>\\[\\]?^~`])(?=.{8,128})");

        setPasswordError(
            regex.test(formValues.password) ? setValidatedPassword(true) :
                'Not a valid password')

    }
    const validateConfirmPassword = () => {

        setConfirmPasswordError((formValues.retypepassword === formValues.password) ?
            setvalidatedconfirmpassword(true) : 'should match with password')
    }

    const getURL = () => {
        let url = (`http://localhost:4000/register`)
        return url;
    }
    
    const handleSubmit = () => {       
        axios.post(getURL(), { formValues }, {
            'Content-Type': 'application/json',
        }).then(function (response) {
            if (response.status >= 400) {
                throw new Error("Bad response from server");
            }
            return response.data;
        }).then(function (data) {           
           alert("Registered sucessfully");
        }).catch(err => {
            setErrorMsg(err.response);
        })

    }

    return (
        <Box
            sx={{
                padding: '130px 150px',
                margin: '5px 350px',
                width: 300,
                height: 300,
                backgroundColor: 'lightgrey',
                borderRadius: '20px'
            }}
        >
          <form>
                <TextField
                    required
                    id="outlined-required"
                    label="First Name"
                    name="firstname"
                    value={formValues.firstname}
                    onChange={handleInputChange}
                />
                <TextField
                    required
                    id="outlined-required"
                    label="Last Name"
                    name="lastname"
                    value={formValues.lastname}
                    onChange={handleInputChange}
                />
                <TextField
                    required
                    id="outlined-required"
                    label="OracleID"
                    name="oracleID"
                    value={formValues.oracleID}
                    onChange={handleInputChange}
                />
                <TextField
                    required
                    id="outlined-required"
                    type="email"
                    label="Email ID"
                    name="emailID"
                    value={formValues.emailID}
                    onChange={handleInputChange}
                /><br/>
                <TextField
                    required
                    id="outlined-required" type=""
                    label="Employee ID"
                    name="employeeID"
                    value={formValues.employeeID}
                    onChange={handleInputChange}
                /><br/>
               
                    <InputLabel id="demo-simple-select-label">Access Type</InputLabel>
                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={formValues.accesstype}
                        label="Access Type"
                        name="accesstype"
                        onChange={handleInputChange}
                    >
                        <MenuItem value="ADMIN">Admin</MenuItem>
                        <MenuItem value="READ-ONLY">Guest User</MenuItem>
                       
                    </Select><br/>
              
                <TextField
                    id="outlined-password-input"
                    label="Password"
                    type="password"
                    autoComplete="current-password"
                    name="password"
                    value={formValues.password}
                    onChange={handleInputChange}
                />
                <span>  <div> {passwordError}</div></span>
                <TextField
                    id="outlined-password-input"
                    label="Retype Password"
                    type="password"
                    name="retypepassword"
                    autoComplete="current-password"
                    onChange={handleInputChange}
                    onBlur={validateConfirmPassword}
                />
                <span>  <div> {confirmPasswordError}</div></span>
                <br />
                <Button
                    variant="contained"
                    color="primary"
                    type="submit"
                    endIcon={<SendIcon></SendIcon>}
                    onClick={handleSubmit}
                >Submit</Button>
          </form>
        </Box>
    );
}