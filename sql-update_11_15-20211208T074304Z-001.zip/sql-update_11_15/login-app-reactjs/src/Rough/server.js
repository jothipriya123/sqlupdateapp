require('dotenv').config();
const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const utils = require('./utils');
const oracledb = require('oracledb');
const app = express();
const port = process.env.PORT || 4000;
var password = "sa";

app.use(cors());
var bodyParser = require('body-parser');
const { autoCommit } = require('oracledb');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
var result_data = {}

async function registerData(req, res) {

  const {employeeID,firstname,lastname,emailID,accesstype,oracleID,password}= req.body.formValues;   
  oracledb.getConnection({
    user: "sa",
    password: "sa",
    connectString: "tbss4db:1581/TBSS4"
  }, function(err,con){
    if(err){
      console.log("Error...")
      res.send('db con error');
    }
    else{
      console.log("Connected....")
      var q="insert into sqluserlist values('"+employeeID+"','"+firstname+"','"+lastname+"','"+emailID+"','"+password+"','"+accesstype+"','"+oracleID+"')";
      con.execute(q,[],{autoCommit:true}, function(e,s){
        if(e){
          res.send(e);
        }
        else{
          console.log(s)
          res.send(s);
        }
      })
    }
  });
}
async function displaydata(req, res) {

  try {
    connection = await oracledb.getConnection({
      user: "sa",
      password: password,
      connectString: "tbss4db:1581/TBSS4"
    });

    console.log('connected to database');

    var query = ""
    var table = req.body.tables;
    var schema = "";
    var application = `${req.body.processes}`
    var columns = req.body.columns;
    var condition = req.body.condition;
    if (application === "ABP") {
      schema = "pdcustc"
    }
    else if (application === "CRM") {
      schema = "pcrm"
    }
    else if (application === "OMS") {
      schema = "poms"
    }
    if (condition === null) {
      query = `select ${columns} from ${table}`;
    }
    else {
      query = `select ${columns} from ${table} where ${condition}`;
    }
    result = await connection.execute(query, [], { outFormat: oracledb.OUT_FORMAT_OBJECT });
    if (result.rows.length == 0) {
      console.log("Data return query send no rows")
      return res.send('query send no rows');
    } else {   
      console.log("Data return", result.rows)   
      res.send(result.rows);
    }
  }
  catch (err) {
    return res.send(err.message);
  } finally {
    if (connection) {
      try {
        await connection.close();
        console.log('close connection success');
      } catch (err) {
        console.error(err.message);
      }
    }

  }
}
async function application(req, res) {

  try {
    connection = await oracledb.getConnection({
      user: "sa",
      password: password,
      connectString: "tbss4db:1581/TBSS4"
    });

    console.log('connected to database');
    result = await connection.execute(`select * from applications`, [], { outFormat: oracledb.OUT_FORMAT_OBJECT });
    if (result.rows.length == 0) {
      return res.send('query send no rows');
    } else {
      result_data.application = result.rows;
      try {
        result = await connection.execute(`select DISTINCT table_id, table_name from test_tables`, [], {})
        if (result.rows.length == 0) {
          return res.send('query send no rows');
        }
        else {
          result_data.tables = result.rows;
          try {
            result = await connection.execute(`select table_name, column_name from test_tables_column`, [], {})
            if (result.rows.length == 0) {
              return res.send('query send no rows');
            }
            else {
              result_data.columns = result.rows;
              return res.send(result_data);
            }
          } catch (err) {
            return res.send(err.message);
          }
        }
      } catch (err) {
        return res.send(err.message);
      }
    }
  }
  catch (err) {
    return res.send(err.message);
  } finally {
    if (connection) {
      try {
        await connection.close();
        console.log('close connection success');
      } catch (err) {
        console.error(err.message);
      }
    }

  }
}


app.get('/application', function (req, res) {
  application(req, res);
});

app.post('/register', (req, res) => {  
  registerData(req, res);
})

app.post('/select', (req, res) => {
  displaydata(req, res);
})


app.listen(port, () => {
  console.log('Server started on: ' + port);
});
