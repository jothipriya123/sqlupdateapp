# auth-api-nodejs
Create REST API for authentication in Node.js using JWT

Please check the below link for step by step tutorial
**https://www.cluemediator.com/create-rest-api-for-authentication-in-node-js-using-jwt**

## Setup
Follow below steps to run project

1. Clone repository
2. Run `npm i` command to install dependencies
3. Execute `npm start` command to run the project

### Connect with us:
Website: https://www.cluemediator.com  
Facebook: https://www.facebook.com/thecluemediator  
Twitter: https://twitter.com/cluemediator  
Telegram: https://t.me/cluemediator

