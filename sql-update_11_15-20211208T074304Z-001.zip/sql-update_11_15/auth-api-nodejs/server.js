require('dotenv').config();
const express = require('express')
const oracledb = require('oracledb');
const app = express();
const port = process.env.PORT || 4000;
var password = "sa";
const cors = require('cors');
const jwt = require('jsonwebtoken');
const utils = require('./utils');

// enable CORS
app.use(cors());
var bodyParser = require('body-parser');
const { request } = require('express');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;

let userData = null;
var allUsers = [];
let table_name = null;

async function testDatabase(req, res) {
  try {
    connection = await oracledb.getConnection({
      user: "sa",
      password: password,
      connectString: "tbss4db:1581/TBSS4"
    });

    console.log('connected to database');
    result = await connection.execute(`SELECT * FROM sqluserlist`);
    console.log("after result");
    if (result.rows.length == 0) {
      console.log("inside if");
      return res.send('query send no rows');
    } else {
      console.log("inside else");
      allUsers = result.rows;
      console.log("All Users user test",allUsers);
      return res.send(result.rows);
    }
    //app.listen();
  } catch (err) {
    return res.send(err.message);
  } finally {
    if (connection) {
      try {
        //await connection.close();
        console.log('close connection success');
      } catch (err) {
        console.error(err.message);
      }
    }
   
  }
}
app.get('/testconnect', function (req, res) {
  testDatabase(req, res);
})

//middleware that checks if JWT token exists and verifies it if it does exist.
//In all future routes, this helps to know if the request is authenticated or not.
app.use(function (req, res, next) {
  // check header or url parameters or post parameters for token
  var token = req.headers['authorization'];
  if (!token) return next(); //if no token, continue

  token = token.replace('Bearer ', '');
  jwt.verify(token, process.env.JWT_SECRET, function (err, user) {
    if (err) {
      return res.status(401).json({
        error: true,
        message: "Invalid user."
      });
    } else {
      req.user = user; //set the user to req so other routes can use it
      next();
    }
  });
});


// request handlers
app.get('/', (req, res) => {
  console.log(req.user);
  if (!req.user) return res.status(401).json({ success: false, message: 'Invalid user to access it.' });
  res.send('Welcome to the SQL update Dashboard! - ' + req.user.name);
});

let my_user = null;
/*connection.execute('SELECT * FROM sqlupdate.sqluser', function (error, results) {
  if (error) throw error;
  allUsers = results;
  //console.log("All users",allUsers);
      
});*/

// validate the user credentials
app.post('/validateuser', function (req, res) {
  //testDatabase(req, res);
  console.log("inside validate:", allUsers);

  const user = req.body.username;
  const pwd = req.body.password;

  for (let index = 0; index < allUsers.length; ++index) {
    let eachuser = allUsers[index]
    console.log(eachuser.NTLOGIN);
    console.log("Upper case:",eachuser.NTLOGIN.toUpperCase(), user.toUpperCase() )
    if(eachuser.NTLOGIN.toUpperCase() === user.toUpperCase()){
        my_user = eachuser;
        break;
    }
  }
   userData = my_user;
  // return 400 status if username/password is not exist
  if (user.length === 0 || pwd.length === 0) {
    console.log("user", user, "user.length", user.length);
    return res.status(400).json({
      error: true,
      message: "Username or Password required."
    });
  }

  // return 401 status if the credential is not match.
  if (user.toUpperCase() !== userData.NTLOGIN.toUpperCase()) {
    //console.log("status", res);
    return res.status(401).json({
      error: true,
      message: "Invalid Username."
    });
  }

  if (pwd !== userData.PASSWORD) {
    //console.log("status", res);
    return res.status(401).json({
      error: true,
      message: "Wrong Password."
    });
  }

  // generate token
  console.log("userData", userData, userData.FIRST_NAME);
  const token = utils.generateToken(userData);
  // get basic user details
  const userObj = utils.getCleanUser(userData);
  // return the token along with user details
  return res.json({ user: userObj, token });
});


// verify the token and return it if it's valid
app.get('/verifyToken', function (req, res) {
  // check header or url parameters or post parameters for token
  var token = req.body.token || req.query.token;
  if (!token) {
    return res.status(400).json({
      error: true,
      message: "Token is required."
    });
  }
  // check token that was passed by decoding token using secret
  jwt.verify(token, process.env.JWT_SECRET, function (err, user) {
    if (err) return res.status(401).json({
      error: true,
      message: "Invalid token."
    });

    // return 401 status if the oracleid does not match.
    if (user.oracleid !== userData.ORACLEID) {
      return res.status(401).json({
        error: true,
        message: "Invalid user."
      });
    }
    // get basic user details
    var userObj = utils.getCleanUser(userData);
    return res.json({ user: userObj, token });
  });
});

var result_data = {}

async function registerData(req, res) {

  const {employeeID,firstname,lastname,emailID,accesstype,oracleID,password}= req.body.formValues;   
  oracledb.getConnection({
    user: "sa",
    password: "sa",
    connectString: "tbss4db:1581/TBSS4"
  }, function(err,con){
    if(err){
      console.log("Error...")
      res.send('db con error');
    }
    else{
      console.log("Connected....")
      var q="insert into sqluserlist values('"+employeeID+"','"+firstname+"','"+lastname+"','"+emailID+"','"+password+"','"+accesstype+"','"+oracleID+"')";
      con.execute(q,[],{autoCommit:true}, function(e,s){
        if(e){
          res.send(e);
        }
        else{
          console.log(s)
          res.send(s);
        }
      })
    }
  });
}

async function displaydata(req, res) {

  try {
    connection = await oracledb.getConnection({
      user: "sa",
      password: password,
      connectString: "tbss4db:1581/TBSS4"
    });

    console.log('connected to database');

    var query = ""
    var table = req.body.tables;
    table_name = table;
    var schema = "";
    var application = `${req.body.processes}`
    var columns = req.body.columns;
    var condition = req.body.condition;

    console.log("Columns CC:", columns);
  
    console.log("req: ", req.body);
    console.log("Request.body.condition:", req.body.condition);
    if (application === "ABP") {
      schema = "pdcustc"
    }
    else if (application === "CRM") {
      schema = "pcrm"
    }
    else if (application === "OMS") {
      schema = "poms"
    }
    if (condition === undefined) {
      console.log("Before query if statement", condition);
      query = `select ${columns} from ${table}`;
      console.log("After query if statement", condition);
    }
    else {
      console.log("Before query else statement", condition);
      query = `select ${columns} from ${table} where ${condition}`;
      console.log("After query else statement", condition);
    }
    result = await connection.execute(query, [], { outFormat: oracledb.OUT_FORMAT_OBJECT });
    if (result.rows.length == 0) {
      return res.send('No records found');
    } else {      
      console.log("result: ", result.rows);
      res.send(result.rows);
    }
  }
  catch (err) {
    return res.send(err.message);
  } finally {
    if (connection) {
      try {
        await connection.close();
        console.log('close connection success');
      } catch (err) {
        console.error(err.message);
      }
    }

  }
}
async function application(req, res) {

  try {
    connection = await oracledb.getConnection({
      user: "sa",
      password: password,
      connectString: "tbss4db:1581/TBSS4"
    });

    console.log('connected to database');
    result = await connection.execute(`select * from applications`, [], { outFormat: oracledb.OUT_FORMAT_OBJECT });
    if (result.rows.length == 0) {
      return res.send('No records found');
    } else {
      result_data.application = result.rows;
      try {
        result = await connection.execute(`select DISTINCT table_id, table_name from test_tables`, [], {})
        if (result.rows.length == 0) {
          return res.send('No records found');
        }
        else {
          result_data.tables = result.rows;
          try {
            result = await connection.execute(`select table_name, column_name from test_tables_column`, [], {})
            if (result.rows.length == 0) {
              return res.send('No records found');
            }
            else {
              result_data.columns = result.rows;
              //return res.send(result_data);
              try {
                result = await connection.execute(`select table_name, select_status, update_status, delete_status, user_id from test_tables`, [], {})
                if (result.rows.length == 0) {
                  return res.send('No records found');
                }
                else {
                  result_data.permissions = result.rows;
                  console.log("result_data:", result_data);
                  return res.send(result_data);
                }
              } catch (err) {
                return res.send(err.message);
              }
            }
          } catch (err) {
            return res.send(err.message);
          }
        }
      } catch (err) {
        return res.send(err.message);
      }
    }
  }
  catch (err) {
    return res.send(err.message);
  } finally {
    if (connection) {
      try {
        await connection.close();
        console.log('close connection success');
      } catch (err) {
        console.error(err.message);
      }
    }

  }
}

async function updateData(req, res) {

  /*var date = Date.parse('2021-11-11T07:00:00.000Z');
  if(isNaN(date))
    console.log('This is not date:', date);
  else
    console.log('This is date object:', new Date(date).toLocaleDateString("en-US"));*/
  const updatedRecords = req.body.updatedRecords;
  const seqNo = req.body.seqNo;
  console.log(seqNo);
  console.log(updatedRecords, 'length:', Object.keys(updatedRecords).length);
  var table = table_name;
  console.log(table); 
  var u_columns = Object.keys(updatedRecords);
  console.log("u_columns:", u_columns);
  var u_values = Object.values(updatedRecords);
  console.log("u_values:", u_values);
  let update_str = '';
  
  for(var i=0; i< Object.keys(updatedRecords).length-1; i++)
  {
    console.log("i:", i, "u_columns[i]", u_columns[i]);
    update_str= update_str+''+u_columns[i]+"='"+u_values[i]+"',";
  }
  update_str= update_str+''+u_columns[Object.keys(updatedRecords).length-1]+'='+"'"+u_values[Object.keys(updatedRecords).length-1]+"'";
  console.log('update_str', update_str);   
  oracledb.getConnection({
    user: "sa",
    password: "sa",
    connectString: "tbss4db:1581/TBSS4"
  }, function(err,con){
    if(err){
      console.log("Error...")
      res.send('db con error');
    }
    else{
      console.log("Connected....")
      var q=`update ${table} set ${update_str} where seq_no = ${seqNo}`;
      con.execute(q,[],{autoCommit:true}, function(e,s){
        if(e){
          res.send(e);
        }
        else{
          console.log(s)
          res.send(s);
        }
      })
    }
  });
}

async function deleteData(req, res) {
  const seqNo = req.params.seqNo;
  /*var table = req.body.table;*/
  var table = table_name; 
  console.log("Inside Delete")
  console.log("seqNo:", seqNo);
  console.log("table:", table);
  //const {employeeID,firstname,lastname,emailID,accesstype,oracleID,password}= req.body.formValues;   
  oracledb.getConnection({
    user: "sa",
    password: "sa",
    connectString: "tbss4db:1581/TBSS4"
  }, function(err,con){
    if(err){
      console.log("Error...")
      res.send('db con error');
    }
    else{
      console.log("Connected....")
      var q=`delete from ${table} where seq_no = ${seqNo}`;
      con.execute(q,[],{autoCommit:true}, function(e,s){
        if(e){
          res.send(e);
        }
        else{
          console.log(s)
          res.send(s);
        }
      })
    }
  });
}

app.post('/register', (req, res) => {  
  registerData(req, res);
})

app.get('/application', function (req, res) {
  application(req, res);
});

app.post('/select', (req, res) => {
  displaydata(req, res);
})

app.put('/update', (req, res) => {
  updateData(req, res);
})

app.delete('/delete/:seqNo', (req, res) =>{
  deleteData(req, res);
  //const seqNo = req.params.seqNo
})

app.listen(port, () => {
  console.log('Server started on: ' + port);
});
